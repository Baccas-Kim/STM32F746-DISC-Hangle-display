/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2019 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "adc.h"
#include "crc.h"
#include "dcmi.h"
#include "dma2d.h"
#include "eth.h"
#include "fatfs.h"
#include "i2c.h"
#include "ltdc.h"
#include "quadspi.h"
#include "rtc.h"
#include "sai.h"
#include "sdmmc.h"
#include "spdifrx.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "usb_host.h"
#include "gpio.h"
#include "fmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery.h"
#include "stm32746g_discovery_ts.h"
//#define TFTLCD_TEXT_H_
#include "moon.h"
#include "tftlcd_text.h"


//#include "../../Utilities/Fonts/fonts.h" /*

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */


void test_graphic();
void test_hangeul();
void font_test();
void fill_rectangle_test();
void testdrawline();


#define RGB565_BLACK       0x0000      /*   0,   0,   0 */
#define RGB565_NAVY        0x000F      /*   0,   0, 128 */
#define RGB565_DARKGREEN   0x03E0      /*   0, 128,   0 */
#define RGB565_DARKCYAN    0x03EF      /*   0, 128, 128 */
#define RGB565_MAROON      0x7800      /* 128,   0,   0 */
#define RGB565_PURPLE      0x780F      /* 128,   0, 128 */
#define RGB565_OLIVE       0x7BE0      /* 128, 128,   0 */
#define RGB565_LIGHTGREY   0xC618      /* 192, 192, 192 */
#define RGB565_DARKGREY    0x7BEF      /* 128, 128, 128 */
#define RGB565_BLUE        0x001F      /*   0,   0, 255 */
#define RGB565_GREEN       0x07E0      /*   0, 255,   0 */
#define RGB565_CYAN        0x07FF      /*   0, 255, 255 */
#define RGB565_RED         0xF800      /* 255,   0,   0 */
#define RGB565_MAGENTA     0xF81F      /* 255,   0, 255 */
#define RGB565_YELLOW      0xFFE0      /* 255, 255,   0 */
#define RGB565_WHITE       0xFFFF      /* 255, 255, 255 */
#define RGB565_ORANGE      0xFD20      /* 255, 165,   0 */
#define RGB565_GREENYELLOW 0xAFE5      /* 173, 255,  47 */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

TS_StateTypeDef TS_State;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	 uint16_t x=0, y=0;
	 uint8_t str[4]={0,};
	 uint8_t zero = 0;

	 SCB_EnableICache();
	  SCB_EnableDCache();
	  //MPU_Config();

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC3_Init();
  //MX_CRC_Init();
  //MX_DCMI_Init();
  MX_DMA2D_Init();
  //MX_ETH_Init();
  MX_FMC_Init();
  MX_I2C1_Init();
  MX_I2C3_Init();
  MX_LTDC_Init();
  MX_QUADSPI_Init();
  //MX_RTC_Init();
  //MX_SAI2_Init();
  //MX_SDMMC1_SD_Init();
  //MX_SPDIFRX_Init();
  MX_SPI2_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM5_Init();
  MX_TIM8_Init();
  MX_TIM12_Init();
  MX_USART1_UART_Init();
  MX_USART6_UART_Init();
  /* USER CODE BEGIN 2 */


  BSP_LCD_Init();
  BSP_TS_Init(480,272);
  BSP_LCD_LayerRgb565Init(0, LCD_FB_START_ADDRESS);
  BSP_LCD_DisplayOn();
  BSP_LCD_SelectLayer(0);
  BSP_LCD_SetTransparency(0, 255);

  BSP_LCD_Clear(RGB565_BLACK);
  BSP_LCD_SetTextColor(RGB565_WHITE);
  BSP_LCD_SetBackColor(RGB565_BLACK);
  BSP_LCD_SetFont(&Font8);

  char BUF[] = "All work and no play makes Jack a dull boy";

  uint16_t count=0;
  uint16_t iter=0;

  test_hangeul();
 // test_graphic();
  HAL_Delay(250);
  BSP_LCD_Clear(RGB565_BLACK);

  /* USER CODE END 2 */

  /* Call init function for freertos objects (in freertos.c) */
 // MX_FREERTOS_Init();

  /* Start scheduler */
  //osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

      tft_string( rand()%480 , rand()%272, RGB565_YELLOW      , RGB565_BLACK , (uint8_t *)"����");
      HAL_Delay(10);
      tft_string( rand()%480 , rand()%272, RGB565_RED    , RGB565_BLACK , (uint8_t *)"�α�");
      HAL_Delay(10);
      tft_string( rand()%480 , rand()%272, RGB565_BLUE        , RGB565_BLACK , (uint8_t *)"����");
      HAL_Delay(10);

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /**Configure LSE Drive Capability 
  */
  HAL_PWR_EnableBkUpAccess();
  /**Configure the main internal regulator output voltage 
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 400;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /**Activate the Over-Drive mode 
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_6) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_SPDIFRX|RCC_PERIPHCLK_LTDC
                              |RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_USART1
                              |RCC_PERIPHCLK_USART6|RCC_PERIPHCLK_SAI2
                              |RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_I2C3
                              |RCC_PERIPHCLK_SDMMC1|RCC_PERIPHCLK_CLK48;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 100;
  PeriphClkInitStruct.PLLI2S.PLLI2SP = RCC_PLLP_DIV2;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  PeriphClkInitStruct.PLLI2S.PLLI2SQ = 2;
  PeriphClkInitStruct.PLLSAI.PLLSAIN = 384;
  PeriphClkInitStruct.PLLSAI.PLLSAIR = 5;
  PeriphClkInitStruct.PLLSAI.PLLSAIQ = 2;
  PeriphClkInitStruct.PLLSAI.PLLSAIP = RCC_PLLSAIP_DIV8;
  PeriphClkInitStruct.PLLI2SDivQ = 1;
  PeriphClkInitStruct.PLLSAIDivQ = 1;
  PeriphClkInitStruct.PLLSAIDivR = RCC_PLLSAIDIVR_8;
  PeriphClkInitStruct.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  PeriphClkInitStruct.Sai2ClockSelection = RCC_SAI2CLKSOURCE_PLLSAI;
  PeriphClkInitStruct.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
  PeriphClkInitStruct.Usart6ClockSelection = RCC_USART6CLKSOURCE_PCLK2;
  PeriphClkInitStruct.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  PeriphClkInitStruct.I2c3ClockSelection = RCC_I2C3CLKSOURCE_PCLK1;
  PeriphClkInitStruct.Clk48ClockSelection = RCC_CLK48SOURCE_PLLSAIP;
  PeriphClkInitStruct.Sdmmc1ClockSelection = RCC_SDMMC1CLKSOURCE_CLK48;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void font_test()
{
    sFONT *myFont[5] = {&Font24, &Font20, &Font16, &Font12, &Font8 };
    uint32_t tcolor;

    BSP_LCD_Clear(LCD_COLOR_WHITE);

    for(uint16_t k=0; k<500; k++) {
        tcolor  = 0xff000000;
        tcolor |= (rand() & 0xff) << 16;
        tcolor |= (rand() & 0xff) << 8;
        tcolor |= (rand() & 0xff);

        BSP_LCD_SetTextColor(tcolor);
        BSP_LCD_SetFont(myFont[rand()%5]);
        BSP_LCD_DisplayStringAt(rand()%480, rand()%272, (uint8_t *) "Font test ABC abc 123 !@#", LEFT_MODE);
        HAL_Delay(10);
    }
    HAL_Delay(500);
}

void fill_rectangle_test()
{
    uint32_t tcolor;

    BSP_LCD_Clear(LCD_COLOR_WHITE);

    for(uint16_t k=0; k<500; k++) {
        tcolor  = 0xff000000;
        tcolor |= (rand() & 0xff) << 16;
        tcolor |= (rand() & 0xff) << 8;
        tcolor |= (rand() & 0xff);

        BSP_LCD_SetTextColor(tcolor);
        BSP_LCD_DrawRect(rand()%480, rand()%272, rand()%480, rand()%272);
        HAL_Delay(10);
    }
    HAL_Delay(500);
}


void testdrawline() {
    BSP_LCD_Clear(RGB565_BLACK);
    for (int16_t i=0; i<480; i+=8) {
        BSP_LCD_DrawLine(0, 0, i, 272-1);
        HAL_Delay(10);
    }
    for (int16_t i=0; i<272; i+=8) {
        BSP_LCD_DrawLine(0, 0, 480-1, i);
        HAL_Delay(10);
    }
    HAL_Delay(250);

    BSP_LCD_Clear(RGB565_BLACK);
    for (int16_t i=0; i<480; i+=8) {
        BSP_LCD_DrawLine(0, 272-1, i, 0);
        HAL_Delay(10);
    }
    for (int16_t i=272-1; i>=0; i-=8) {
        BSP_LCD_DrawLine(0, 272-1, 480-1, i);
        HAL_Delay(10);
    }
    HAL_Delay(250);

    BSP_LCD_Clear(RGB565_BLACK);
    for (int16_t i=480-1; i>=0; i-=8) {
        BSP_LCD_DrawLine(480-1, 272-1, i, 0);
        HAL_Delay(10);
    }
    for (int16_t i=272-1; i>=0; i-=8) {
        BSP_LCD_DrawLine(480-1, 272-1, 0, i);
        HAL_Delay(10);
    }
    HAL_Delay(250);

    BSP_LCD_Clear(RGB565_BLACK);
    for (int16_t i=0; i<272; i+=8) {
        BSP_LCD_DrawLine(480-1, 0, 0, i);
        HAL_Delay(10);
    }
    for (int16_t i=480-1; i>=0; i-=8) {
        BSP_LCD_DrawLine(480-1, 0, i, 272-1);
        HAL_Delay(10);
    }
    HAL_Delay(250);
}


void test_hangeul()
{
    uint32_t tcolor;

    BSP_LCD_SelectLayer(0);
    BSP_LCD_Clear(LCD_COLOR_BLACK);

    for(uint16_t ch=0; ch < 500; ch++) {
        tcolor  = 0xff000000;
        tcolor |= (rand() & 0xff) << 16;
        tcolor |= (rand() & 0xff) << 8;
        tcolor |= (rand() & 0xff);

        tft_string( rand()%480 , rand()%272, tcolor, LCD_COLOR_BLACK , (uint8_t *)"�ѱ� �׽�Ʈ ���ѹα� Test abcd 1234 ~!");
        //HAL_Delay(5);
    }
}

void test_graphic()
{
    uint16_t radius;

    BSP_LCD_SelectLayer(1);
    BSP_LCD_Clear(LCD_COLOR_WHITE);

    BSP_LCD_SetTextColor(LCD_COLOR_RED);
    for(radius=1; radius<272/2; radius++) {
        BSP_LCD_DrawCircle(480/2, 272/2, radius);
        HAL_Delay(3);
    }
    BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
    for(radius=272/2; radius>0; radius--) {
        BSP_LCD_DrawCircle(480/2, 272/2, radius);
        HAL_Delay(3);
    }
    HAL_Delay(500);
}



/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
