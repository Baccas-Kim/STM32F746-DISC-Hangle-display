/*
 * tftlcd_text.h
 *
 *  Created on: 2017. 6. 6.
 *      Author:
 */

#ifndef TFTLCD_TEXT_H_
#define TFTLCD_TEXT_H_

/*
 ******************************************************************************
 *
 *		TFT ��¿� ������ �ѱ�, ����, Ư������ ���� ��ƾ
 *		- �ҽ� ���� : ������ �������� OK-128DCM.h
 *
 ******************************************************************************
 */

#include "stm32f7xx_hal.h"
#include "stm32746g_discovery_lcd.h"

/*
 *******************************************************************************
 *
 *	User Functions
 *
 *******************************************************************************
 */
void tft_char_xy(uint8_t x, uint8_t y);
void tft_color(uint16_t f_color, uint16_t b_color);
void tft_string(uint8_t xc, uint8_t yc, uint32_t colorfore, uint32_t colorback, uint8_t *str);
void tft_english(uint8_t code);
unsigned int ks_code_conversion(uint16_t kssm);
void tft_korean(uint16_t code);

/* ---------------------------------------------------------------------------- */
/*		Variables for TFT-LCD Module					*/
/* ---------------------------------------------------------------------------- */

//u08 _xchar_limit = 40;			// character number of line (30 or 40)
//u08 _ychar_limit = 30;			// line number of screen (40 or 30)
uint8_t _xchar;						// (0-29) for portrait, (0-39) for landscape
uint8_t _ychar;						// (0-39) for portrait, (0-29) for landscape
uint32_t fg_color;					// foreground color
uint32_t bg_color;					// background color

#endif /* TFTLCD_TEXT_H_ */
